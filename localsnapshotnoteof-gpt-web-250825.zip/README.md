# Local Snapshot Note of GPT Web

This repository contains a set of Python modules and command‐line tools for
collecting, normalising and analysing browsing and chat data from your own
machine.  The goal of the project is to provide a *self‑hosted*,
privacy‑preserving pipeline that can:

* Take a one‑off snapshot of every open browser tab on your system.
* Ingest browsing history from Chromium‑based browsers (e.g. Chrome, Edge,
  Brave) and Firefox.
* Import your ChatGPT conversation export (JSON) and convert it into a
  convenient tabular form.
* Normalise all of the above into a unified schema with eight required
  columns (`id`, `source`, `title`, `url`, `domain`, `ts`,
  `text_excerpt`, `profile`) and optional metadata.
* Generate dense vector embeddings for each item using a sentence
  transformer.  By default we use the
  [`all‑MiniLM‑L6‑v2`](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2)
  model, but you can substitute your own model via CLI flags.
* Reduce those vectors down to a two‑dimensional space using UMAP and
  optionally cluster them with HDBSCAN or K‑means.
* Produce a “dot” map as a static PNG/SVG as well as an interactive HTML
  viewer where each dot is clickable (hyperlinked to the original URL).
  Distances in the scatter plot correspond to semantic similarity, and
  edges may be drawn between nearest neighbours if you enable them.

The project is modular and broken down into a number of small
components—collectors, normalisers, embedders, projectors, clusterers
and renderers—so you can swap parts in and out as your needs change.

## Usage

Install dependencies (preferably in a virtual environment):

```bash
pip install -r requirements.txt
```

Collect data (history, tabs and ChatGPT export) and build a map:

```bash
# Collect history and open tabs into CSV files under ./data/collections
python -m surfkit.collectors.history_ingest --since 90d --browsers chrome,firefox \
  --output ./data/collections/history.csv
python -m surfkit.collectors.tabs_snapshot --output ./data/collections/tabs.csv
python -m surfkit.collectors.chatgpt_ingest --export ~/Downloads/chatgpt_export.zip \
  --output ./data/collections/chat.csv

# Normalise into a unified table
python -m surfkit.pipeline.normalize \
  --inputs ./data/collections/tabs.csv ./data/collections/history.csv ./data/collections/chat.csv \
  --output ./data/unified.csv

# Embed and project
python -m surfkit.pipeline.embed --input ./data/unified.csv --output ./data/embeddings.parquet
python -m surfkit.pipeline.project_umap --input ./data/embeddings.parquet --output ./data/positions.csv

# Cluster (optional) and render
python -m surfkit.pipeline.cluster --input ./data/embeddings.parquet --output ./data/clusters.csv
python -m surfkit.renderer.render_scatter \
  --positions ./data/positions.csv --clusters ./data/clusters.csv \
  --unified ./data/unified.csv --output ./out/scatter.png --html ./out/viewer.html
```

See each module’s `--help` output for more options (e.g. specifying a
different embedding model, toggling edge drawing, or adjusting UMAP
parameters).  All scripts are safe to run offline after the initial model
download.

## Security and privacy

This project is designed to run *entirely on your own machine*.  No data
ever leaves your computer unless you explicitly share it.  You have full
control over what sources are ingested and can redact sensitive
information via regular expressions configured in `surfkit/config.py` or
CLI flags.  For your own protection please do not point the ingestion
tools at anyone else’s browser profiles or ChatGPT exports.

## Disclaimer

This software is provided as‑is.  It is intended as a research and
productivity aid; use it responsibly and at your own risk.