"""Utility functions for SurfKit.

This module defines a handful of helper routines used throughout the
project, including URL canonicalisation, ID generation and date parsing.
"""

from __future__ import annotations

import hashlib
import re
import urllib.parse
from datetime import datetime, timedelta
from typing import Optional, Iterable, List, Tuple

import tldextract

ISO_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

# Regular expressions for stripping common tracking query parameters.
TRACKING_PARAMS = re.compile(
    r"^(utm_[^=]+|fbclid|gclid|token|code|session|s|S|ref|referrer)$",
    re.IGNORECASE,
)


def canonicalise_url(url: str) -> str:
    """Canonicalise a URL by lowercasing the scheme and host and stripping
    common tracking parameters.

    We do **not** modify the path, and we keep query parameters that do not
    match the `TRACKING_PARAMS` pattern.  Fragments are dropped entirely.
    """
    if not url:
        return url
    parsed = urllib.parse.urlsplit(url.strip())
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    path = parsed.path
    # Filter query parameters
    query_params = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    filtered = [
        (k, v)
        for k, v in query_params
        if not TRACKING_PARAMS.match(k)
    ]
    query = urllib.parse.urlencode(filtered)
    return urllib.parse.urlunsplit((scheme, netloc, path, query, ""))


def extract_domain(url: str) -> str:
    """Extract the registrable domain from a URL.

    If parsing fails the original hostname is returned.  The `tldextract`
    library automatically handles public suffix lists.
    """
    if not url:
        return ""
    parts = tldextract.extract(url)
    if parts.domain and parts.suffix:
        return f"{parts.domain}.{parts.suffix}"
    return parts.domain or parts.subdomain or url


def sha1_id(*values: str) -> str:
    """Compute a stable SHA1 hash of the given values.

    Values are concatenated with a null byte separator before hashing.  This
    ensures that different combinations of strings yield different IDs.
    """
    hasher = hashlib.sha1()
    for idx, value in enumerate(values):
        if idx > 0:
            hasher.update(b"\0")
        if value:
            hasher.update(value.encode("utf-8", errors="ignore"))
    return hasher.hexdigest()


def parse_since(value: str) -> datetime:
    """Parse a relative or absolute date string.

    - If ``value`` ends with ``d``, ``w``, ``m`` or ``y`` it is treated as a
      duration: e.g. ``"90d"`` -> now minus 90 days.  ``w`` = weeks,
      ``m`` = months (30 days), ``y`` = years (365 days).
    - Otherwise we try to parse it as an ISO 8601 date or datetime in the
      user's local timezone (assumed to be Asia/Seoul) and convert to UTC.

    Returns a ``datetime`` in UTC.
    """
    value = value.strip()
    now = datetime.utcnow()
    if not value:
        return datetime.utcfromtimestamp(0)
    match = re.match(r"^(\d+)([dwmy])$", value)
    if match:
        amount = int(match.group(1))
        unit = match.group(2)
        if unit == "d":
            delta = timedelta(days=amount)
        elif unit == "w":
            delta = timedelta(weeks=amount)
        elif unit == "m":
            delta = timedelta(days=30 * amount)
        elif unit == "y":
            delta = timedelta(days=365 * amount)
        else:
            delta = timedelta(0)
        return now - delta
    # Attempt to parse absolute date/time
    for fmt in ["%Y-%m-%d", "%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S"]:
        try:
            dt = datetime.strptime(value, fmt)
            # Assume dt is in local time zone (Asia/Seoul).  Convert to UTC by
            # subtracting nine hours.
            return dt - timedelta(hours=9)
        except ValueError:
            pass
    # Fall back to now
    return now