"""Clustering of embeddings.

This script reads a Parquet file of embeddings and assigns each row to a
cluster label.  By default it uses HDBSCAN to discover clusters with
uneven densities and to label noise points as ``-1``.  If HDBSCAN is
unavailable the script falls back to K‑means with a user‑specified
number of clusters.

The output is a CSV with two columns: ``id`` and ``cluster``.  The
cluster labels are integers where ``-1`` indicates noise (unclustered
points).  When using K‑means the labels will be in the range
``0 .. k-1``.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import List, Optional

import numpy as np  # type: ignore
import pandas as pd  # type: ignore

try:
    import hdbscan  # type: ignore
except ImportError:
    hdbscan = None  # type: ignore

from sklearn.cluster import KMeans  # type: ignore


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--input",
        required=True,
        help="Path to embeddings Parquet file",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to output clusters CSV",
    )
    parser.add_argument(
        "--algorithm",
        choices=["hdbscan", "kmeans"],
        default="hdbscan",
        help="Clustering algorithm to use",
    )
    parser.add_argument(
        "--min-cluster-size",
        type=int,
        default=5,
        help="Minimum cluster size for HDBSCAN",
    )
    parser.add_argument(
        "--n-clusters",
        type=int,
        default=12,
        help="Number of clusters for K‑means fallback",
    )
    parser.add_argument(
        "--random-seed",
        type=int,
        default=42,
        help="Random seed for K‑means",
    )
    args = parser.parse_args(argv)
    df = pd.read_parquet(args.input)
    ids = df["id"].tolist()
    vectors = np.vstack(df["vector"].to_list())
    labels: np.ndarray
    if args.algorithm == "hdbscan" and hdbscan is not None:
        clusterer = hdbscan.HDBSCAN(min_cluster_size=args.min_cluster_size)
        labels = clusterer.fit_predict(vectors)
    else:
        kmeans = KMeans(n_clusters=args.n_clusters, random_state=args.random_seed)
        labels = kmeans.fit_predict(vectors)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "cluster"])
        for rid, label in zip(ids, labels):
            writer.writerow([rid, int(label)])
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())