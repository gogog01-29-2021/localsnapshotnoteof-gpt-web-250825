"""Dimensionality reduction via UMAP.

This script reads a Parquet file of embeddings produced by
``surfkit.pipeline.embed`` and reduces them to two dimensions using
[UMAP](https://umap-learn.readthedocs.io/en/latest/).  The result is
written as a CSV with columns ``id,x,y``.  You can later join these
positions with the unified data and clusters to render plots.

The UMAP parameters ``n_neighbors`` and ``min_dist`` can be tuned via
command‑line flags.  A fixed random seed is used by default to make
layouts reproducible across runs.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import List, Optional

import numpy as np  # type: ignore
import pandas as pd  # type: ignore
import umap  # type: ignore


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--input",
        required=True,
        help="Path to embeddings Parquet file",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to output positions CSV",
    )
    parser.add_argument(
        "--n-neighbors",
        type=int,
        default=15,
        help="UMAP n_neighbors parameter",
    )
    parser.add_argument(
        "--min-dist",
        type=float,
        default=0.1,
        help="UMAP min_dist parameter",
    )
    parser.add_argument(
        "--random-seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    args = parser.parse_args(argv)
    df = pd.read_parquet(args.input)
    ids = df["id"].tolist()
    # Convert list of arrays to 2D numpy array
    vectors = np.vstack(df["vector"].to_list())
    reducer = umap.UMAP(
        n_neighbors=args.n_neighbors,
        min_dist=args.min_dist,
        n_components=2,
        random_state=args.random_seed,
    )
    coords = reducer.fit_transform(vectors)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "x", "y"])
        for rid, (x, y) in zip(ids, coords):
            writer.writerow([rid, float(x), float(y)])
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())