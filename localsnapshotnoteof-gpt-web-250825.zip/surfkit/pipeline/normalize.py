"""Normalise collected CSVs into a unified table.

This script reads one or more CSV files containing records in the
SurfKit schema (or partial schema) and writes a new CSV where every
record conforms to the required columns:

``id, source, title, url, domain, ts, text_excerpt, profile``

Rows are deduplicated on the ``id`` column; the first occurrence of
each unique ID is kept.  The URL and domain are canonicalised using
``surfkit.utils.canonicalise_url`` and ``surfkit.utils.extract_domain``.

Example usage:

```
python -m surfkit.pipeline.normalize --inputs data/collections/tabs.csv data/collections/history.csv \
  --output data/unified.csv
```
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Iterable, List, Optional, Set

from surfkit.utils import canonicalise_url, extract_domain


REQUIRED_FIELDS = ["id", "source", "title", "url", "domain", "ts", "text_excerpt", "profile"]


def normalise_row(row: dict) -> dict:
    """Return a new dict with canonicalised URL and domain.

    Missing keys are filled with empty strings.  The ID and timestamp are
    preserved; we do not regenerate IDs here because collectors are
    responsible for stable ID generation.
    """
    out = {k: row.get(k, "") for k in REQUIRED_FIELDS}
    url = out["url"]
    if url:
        url_clean = canonicalise_url(url)
        domain = extract_domain(url_clean)
    else:
        url_clean = ""
        domain = out.get("domain", "") or ""
    out["url"] = url_clean
    out["domain"] = domain
    return out


def read_rows_from_csv(path: Path) -> Iterable[dict]:
    with path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            yield row


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--inputs",
        nargs="+",
        required=True,
        help="One or more CSV files to normalise.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to write the unified CSV.  Directories will be created if necessary.",
    )
    args = parser.parse_args(argv)
    seen_ids: Set[str] = set()
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=REQUIRED_FIELDS)
        writer.writeheader()
        for input_path in args.inputs:
            path = Path(input_path)
            for row in read_rows_from_csv(path):
                nr = normalise_row(row)
                rid = nr["id"]
                if not rid or rid in seen_ids:
                    continue
                seen_ids.add(rid)
                writer.writerow(nr)
    return 0


if __name__ == "__main__":  # pragma: no cover
    import sys
    raise SystemExit(main())