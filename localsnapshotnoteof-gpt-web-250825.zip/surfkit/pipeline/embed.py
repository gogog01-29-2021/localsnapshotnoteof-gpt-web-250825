"""Embedding generation.

This script reads a unified CSV and produces a Parquet file containing
sentence‑level embeddings for each row.  Embeddings are produced via
[`SentenceTransformer`](https://www.sbert.net) models.  The output
Parquet has two columns:

* ``id``: the row ID (string)
* ``vector``: a list of float32 values (the embedding)

Embeddings are cached in memory and computed in batches.  If the output
file exists it will be overwritten.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import List, Optional

import numpy as np  # type: ignore
import pandas as pd  # type: ignore
from sentence_transformers import SentenceTransformer  # type: ignore

from surfkit.utils import sha1_id


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--input",
        required=True,
        help="Path to unified CSV file",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to output Parquet file",
    )
    parser.add_argument(
        "--model",
        default="sentence-transformers/all-MiniLM-L6-v2",
        help="Sentence transformer model name or path",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=64,
        help="Batch size for embedding generation",
    )
    args = parser.parse_args(argv)
    in_path = Path(args.input)
    out_path = Path(args.output)
    # Load rows
    ids: List[str] = []
    texts: List[str] = []
    with in_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rid = row.get("id")
            if not rid:
                continue
            title = row.get("title", "") or ""
            excerpt = row.get("text_excerpt", "") or ""
            text = (title + " " + excerpt).strip()
            # If no text, fallback to url
            if not text:
                text = row.get("url", "") or ""
            ids.append(rid)
            texts.append(text)
    if not ids:
        sys.stderr.write(f"No rows found in {in_path}\n")
        return 1
    model = SentenceTransformer(args.model)
    embeddings: List[np.ndarray] = []
    # Generate embeddings in batches
    for i in range(0, len(texts), args.batch_size):
        batch = texts[i : i + args.batch_size]
        embs = model.encode(batch, batch_size=len(batch), convert_to_numpy=True, show_progress_bar=True)
        embeddings.extend(embs)
    # Build DataFrame
    df = pd.DataFrame({
        "id": ids,
        "vector": [emb.astype(np.float32) for emb in embeddings],
    })
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())