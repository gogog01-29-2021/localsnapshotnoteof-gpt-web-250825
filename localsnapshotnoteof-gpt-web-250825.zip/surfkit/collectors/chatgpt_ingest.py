"""ChatGPT export ingestion tool.

This script converts the official ChatGPT conversation export format
(contained in the ``conversations.json`` file inside the export ZIP) into
the unified CSV schema used by SurfKit.

Each conversation becomes a single row in the output.  The ``title``
field is taken from the conversation object; the ``ts`` field is the
``create_time`` converted to UTC.  The ``text_excerpt`` is a truncated
preview of the first message in the conversation.  The URL is left
blank because there is no stable URL associated with exported
conversations, and the domain is set to ``chat.openai.com``.

Example usage:

```
python -m surfkit.collectors.chatgpt_ingest --export ~/Downloads/chatgpt_export.zip \
  --output ./data/collections/chat.csv
```
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from surfkit.utils import sha1_id, ISO_FORMAT


def load_conversations(path: Path) -> List[dict]:
    """Load conversations from a ChatGPT export ZIP or directory.

    Returns a list of conversation dicts loaded from ``conversations.json``.
    If the path is a directory, the file is read directly; if it is a
    ZIP archive the file is extracted from within.  Raises if the file
    cannot be found.
    """
    conv_json = None
    if path.is_dir():
        conv_path = path / "conversations.json"
        if not conv_path.exists():
            raise FileNotFoundError(f"{conv_path} not found")
        with conv_path.open("r", encoding="utf-8") as f:
            conv_json = json.load(f)
    else:
        with zipfile.ZipFile(path) as zf:
            try:
                with zf.open("conversations.json") as f:
                    conv_json = json.load(f)
            except KeyError:
                raise FileNotFoundError("conversations.json not found in zip archive")
    return conv_json.get("conversations", conv_json)  # some exports nest under 'conversations'


def extract_excerpt(messages: List[dict], max_len: int = 256) -> str:
    """Return a truncated excerpt of the first message.

    We join message parts if necessary and truncate to `max_len` characters.
    """
    if not messages:
        return ""
    first = messages[0]
    content = ""
    if isinstance(first.get("message", {}).get("content"), dict):
        # Some exports wrap content under a dict with 'parts'
        parts = first["message"].get("content", {}).get("parts", [])
        content = "\n".join(str(p) for p in parts if p)
    elif isinstance(first.get("message", {}).get("content"), str):
        content = first["message"]["content"]
    else:
        # Fallback: attempt to join all message nodes
        content = "".join(str(part) for part in first.get("message", {}).values() if isinstance(part, str))
    content = content.replace("\n", " ")
    return content[:max_len]


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--export",
        required=True,
        help="Path to ChatGPT export ZIP file or directory containing conversations.json",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to CSV file to write.  Directories will be created if necessary.",
    )
    parser.add_argument(
        "--profile",
        default="default",
        help="Profile name to record in the output (useful if you have multiple ChatGPT accounts).",
    )
    args = parser.parse_args(argv)
    export_path = Path(args.export)
    try:
        conversations = load_conversations(export_path)
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        return 1
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["id", "source", "title", "url", "domain", "ts", "text_excerpt", "profile"],
        )
        writer.writeheader()
        for conv in conversations:
            try:
                title = conv.get("title") or "Unnamed conversation"
                # Extract create_time (Unix timestamp) and convert to UTC ISO
                create_ts = conv.get("create_time")
                if create_ts is None:
                    # Some exports store timestamps as milliseconds or iso strings
                    ts_iso = datetime.utcnow().strftime(ISO_FORMAT)
                else:
                    # create_time is seconds since epoch (UTC)
                    dt = datetime.utcfromtimestamp(float(create_ts))
                    ts_iso = dt.strftime(ISO_FORMAT)
                # Build excerpt from first 256 chars of first message
                mapping = conv.get("mapping", {})
                messages = []
                for node_id, node in mapping.items():
                    # Keep only root nodes (no parents) for ordering; we'll sort by index
                    messages.append(node)
                # Sort messages by create_time (if available)
                messages_sorted = sorted(
                    messages,
                    key=lambda m: m.get("message", {}).get("create_time", float("inf"))
                )
                excerpt = extract_excerpt(messages_sorted)
                # Domain is fixed; URL left blank
                url = ""
                domain = "chat.openai.com"
                # Use conversation ID plus timestamp minute for stable ID
                conv_id = str(conv.get("conversation_id") or conv.get("id") or title)
                id_val = sha1_id(conv_id.lower(), ts_iso[:16])
                writer.writerow({
                    "id": id_val,
                    "source": "chatgpt",
                    "title": title,
                    "url": url,
                    "domain": domain,
                    "ts": ts_iso,
                    "text_excerpt": excerpt,
                    "profile": args.profile,
                })
            except Exception as e:
                sys.stderr.write(f"Failed to process conversation: {e}\n")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())