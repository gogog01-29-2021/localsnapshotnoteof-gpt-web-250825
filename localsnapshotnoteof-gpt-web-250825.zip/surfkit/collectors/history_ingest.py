"""History ingestion tool.

This script extracts browsing history from installed browsers using the
``browser_history`` package.  It supports a subset of common Chromium
browsers (Chrome, Edge, Brave, Vivaldi) as well as Firefox.  The
results are written to a CSV file with the following columns:

``id, source, title, url, domain, ts, text_excerpt, profile``

The ``source`` column is fixed to ``"history"`` for all rows emitted by
this tool.  The ``title`` field is left blank because the
``browser_history`` API does not provide titles; users may enrich
records later if desired.

Date filtering can be applied via the ``--since`` flag.  Acceptable
values are durations (e.g. ``90d``, ``12w``) or absolute dates in
``YYYY-MM-DD`` format.  If omitted, all history records are returned.

Example usage:

```
python -m surfkit.collectors.history_ingest --browsers chrome,firefox --since 90d \
  --output ./data/collections/history.csv
```
"""

from __future__ import annotations

import argparse
import csv
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterable, List, Optional

try:
    from browser_history import browsers  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "browser_history is required for history_ingest.  Install with\n"
        "  pip install browser-history\n"
    ) from exc

from surfkit.utils import canonicalise_url, extract_domain, sha1_id, parse_since, ISO_FORMAT


# Mapping of user input names to browser_history classes.
BROWSER_CLASSES = {
    "chrome": browsers.Chrome,
    "firefox": browsers.Firefox,
    "edge": browsers.Edge,
    "brave": browsers.Brave,
    "vivaldi": browsers.Vivaldi,
}


def collect_history_for_browser(name: str, since: datetime) -> Iterable[dict]:
    """Yield history records for a given browser name.

    Each yielded dict will contain the keys required by the unified
    schema.  The ``title`` and ``text_excerpt`` fields are left
    blank because we only have URLs and timestamps from browser_history.
    """
    cls = BROWSER_CLASSES.get(name.lower())
    if cls is None:
        raise ValueError(f"Unsupported browser: {name}")
    try:
        instance = cls()
    except Exception as e:
        sys.stderr.write(f"Failed to initialise {name}: {e}\n")
        return
    try:
        output = instance.history()
    except Exception as e:
        sys.stderr.write(f"Failed to retrieve history for {name}: {e}\n")
        return
    # output.histories is a list of (timestamp, url) tuples
    entries = []
    try:
        # browser_history API versions differ; try both attr names
        entries = output.histories  # type: ignore
    except AttributeError:
        entries = output[1]  # type: ignore
    for ts, url in entries:
        try:
            # Filter by since
            if since and ts < since:
                continue
            url_clean = canonicalise_url(url)
            domain = extract_domain(url_clean)
            ts_iso = ts.strftime(ISO_FORMAT)
            # Use timestamp down to minute resolution for ID
            id_val = sha1_id(url_clean.lower(), ts_iso[:16])
            yield {
                "id": id_val,
                "source": "history",
                "title": "",
                "url": url_clean,
                "domain": domain,
                "ts": ts_iso,
                "text_excerpt": "",
                "profile": name.lower(),
            }
        except Exception as e:
            sys.stderr.write(f"Failed to process history entry ({ts}, {url}): {e}\n")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--browsers",
        default="chrome",
        help="Comma‑separated list of browsers to ingest (chrome, firefox, edge, brave, vivaldi).",
    )
    parser.add_argument(
        "--since",
        default="",  # means all history
        help="Only include history entries on or after this point in time (e.g. 90d, 2025-08-01).",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to CSV file to write.  Directories will be created if necessary.",
    )
    args = parser.parse_args(argv)
    since_dt = parse_since(args.since) if args.since else datetime.utcfromtimestamp(0)
    browsers_list = [b.strip() for b in args.browsers.split(",") if b.strip()]
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["id", "source", "title", "url", "domain", "ts", "text_excerpt", "profile"],
        )
        writer.writeheader()
        for name in browsers_list:
            for record in collect_history_for_browser(name, since_dt):
                writer.writerow(record)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())