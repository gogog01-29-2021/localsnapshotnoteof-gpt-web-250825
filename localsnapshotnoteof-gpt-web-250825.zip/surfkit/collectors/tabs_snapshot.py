"""Open tabs snapshot tool.

This script connects to a running Chromium‑based browser via the DevTools
protocol and retrieves information about currently open tabs.  It
requires that the browser be started with the `--remote-debugging-port`
flag, e.g.:

```
google-chrome --remote-debugging-port=9222
```

The tool writes a CSV file in the unified schema format.  Each row
includes a stable ID based on the URL and timestamp (down to minute),
the tab title, the canonicalised URL, the extracted domain and the
timestamp when the snapshot was taken.

If the DevTools endpoint cannot be reached the script will exit with a
non‑zero status and print an error message.
"""

from __future__ import annotations

import argparse
import csv
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import requests  # type: ignore

from surfkit.utils import canonicalise_url, extract_domain, sha1_id, ISO_FORMAT


def fetch_tabs(port: int) -> List[dict]:
    """Fetch open tabs via the DevTools JSON API.

    Returns a list of dicts containing ``title`` and ``url`` keys.  Tabs
    with empty or non‑HTTP(S) URLs are filtered out.
    """
    try:
        resp = requests.get(f"http://localhost:{port}/json")
        resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"Failed to connect to DevTools at port {port}: {e}") from e
    data = resp.json()
    tabs = []
    for entry in data:
        url = entry.get("url") or ""
        if not url.startswith(("http://", "https://")):
            continue
        tabs.append({
            "title": entry.get("title") or "",
            "url": url,
        })
    return tabs


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--port",
        type=int,
        default=9222,
        help="DevTools remote debugging port.  Default: 9222.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to CSV file to write.  Directories will be created if necessary.",
    )
    parser.add_argument(
        "--profile",
        default="default",
        help="Profile name to record in the output (useful for multi‑profile setups).",
    )
    args = parser.parse_args(argv)
    try:
        tabs = fetch_tabs(args.port)
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        return 1
    ts_iso = datetime.utcnow().strftime(ISO_FORMAT)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["id", "source", "title", "url", "domain", "ts", "text_excerpt", "profile"],
        )
        writer.writeheader()
        for tab in tabs:
            url_clean = canonicalise_url(tab["url"])
            domain = extract_domain(url_clean)
            # ID uses canonical URL and snapshot timestamp down to minute
            id_val = sha1_id(url_clean.lower(), ts_iso[:16])
            writer.writerow({
                "id": id_val,
                "source": "tabs",
                "title": tab["title"],
                "url": url_clean,
                "domain": domain,
                "ts": ts_iso,
                "text_excerpt": "",
                "profile": args.profile,
            })
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())