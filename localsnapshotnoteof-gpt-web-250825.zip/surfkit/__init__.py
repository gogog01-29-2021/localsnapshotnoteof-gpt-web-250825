"""SurfKit package.

This package provides a set of modular tools for collecting and analysing
browsing and chat data.  See the README for an overview.

Each submodule exposes a CLI via ``python -m surfkit.<module> --help``.
"""

__all__ = [
    "collectors",
    "pipeline",
    "renderer",
]